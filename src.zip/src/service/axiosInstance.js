import axios from "axios";

export const API = axios.create(
  // { baseURL: `https://lamp3.ncaa.gov.ng/` } //for store
  // { baseURL: `https://nervy-undiversely-audrea.ngrok-free.dev/` } //for store
  { baseURL: `https://procurement-vh3z.onrender.com/` } //for store
);

API.interceptors.request.use((req) => {
  // Get the token dynamically on each request
  const token = JSON.parse(localStorage.getItem("procurement-auth-session"))
    ?.state?.userData?.token;
  const user = JSON.parse(localStorage.getItem("procurement-auth-session"))
    ?.state?.userData?.data;

  const userD = JSON.stringify({
    staff_id: user?.STAFF_ID,
    staff_name: user?.FIRST_NAME + " " + user?.LAST_NAME,
  });

  req.headers["token"] = token || "";
  req.headers["Authorization"] = userD || "";
  req.headers["Content-type"] = "application/json";
  req.headers["Accept"] = "application/json";
  return req;
});

export const API_GET = axios.create({
  baseURL: `https://hr.ncaa.gov.ng/old_hr/apis/`,
});
API_GET.interceptors.request.use((req) => {
  // Get the token dynamically on each request
  const token = JSON.parse(localStorage.getItem("procurement-auth-session"))
    ?.state?.userData?.token;

  req.headers["token"] = token || "";
  req.headers["Content-type"] = "application/json";
  req.headers["Accept"] = "application/json";
  return req;
});

export const AUTH_API = axios.create({
  baseURL: `https://lamp3.ncaa.gov.ng/`,
});

AUTH_API.interceptors.request.use((req) => {
  req.headers["Content-type"] = "application/json";
  req.headers["Accept"] = "application/json";
  return req;
});

export const LENDNODE_API = axios.create({
  baseURL: `https://lendnode.creditclan.com/memo/api/`,
  // baseURL: `https://ca368d6d2513.ngrok-free.app/api/`,
});
LENDNODE_API.interceptors.request.use((req) => {
  const token = JSON.parse(localStorage.getItem("memo-auth-session"))?.state
    ?.userData?.token;

  req.headers["Authorization"] = `Bearer ${token}`;
  req.headers["Content-type"] = "application/json";
  req.headers["Accept"] = "application/json";
  return req;
});
