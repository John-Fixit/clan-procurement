// src/layout/home-layout/HomeLayout.jsx
import { Outlet } from "react-router-dom";
import useCurrentUser from "../../hooks/useCurrentUser";
import Sidebar, {
  LogoutPopover,
} from "../../components/shared/sidebar/Sidebar";
import { Avatar, Button } from "@heroui/react";
import { FaBars, FaBell } from "react-icons/fa";
import useSidebarStore from "../../hooks/use-sidebar-store";
import { preProfileLink } from "../../utils/pre-profile-link";
import { Dropdown } from "antd";
import clsx from "clsx";
import { CiLogout } from "react-icons/ci";
import AppSwitcher from "../../components/shared/AppSwitcher";

const HomeLayout = () => {
  const { userData } = useCurrentUser();

  const profileData = userData?.data;

  const { toggleSidebar } = useSidebarStore();
  const menuProps = {
    items: [
      {
        label: (
          <p>
            {userData?.data?.FIRST_NAME} {userData?.data?.LAST_NAME}
          </p>
        ),
        key: "user",
      },
      {
        type: "divider",
      },
      {
        label: (
          <LogoutPopover>
            <button
              className={clsx(
                "w-full flex items-center gap-3 rounded-lg text-left text-gray-700 transition-all cursor-pointer",
              )}
            >
              <CiLogout className="text-lg shrink-0" />
              <span className={clsx("text-sm transition-opacity duration-300")}>
                Logout
              </span>
            </button>
          </LogoutPopover>
        ),
        key: "logout",
        danger: true,
      },
    ],
    onClick: () => {},
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navigation Bar */}
        <header className="bg-gray-50 border-b border-gray-200 px-5 md:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {/* <h2 className="text-2xl font-semibold text-gray-800">
              {navItems.find((item) => item.path === location.pathname)
                ?.label || ""}
            </h2> */}
            <div className="cursor-pointer lg:hidden" onClick={toggleSidebar}>
              <FaBars size={23} />
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* <NotificationDropdown /> */}

            {/* <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <span>❓</span>
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <span>👤</span>
            </button> */}

            {/* <div className="flex">
              <AppSwitcher name="argon" title="Argon Apps" />
            </div> */}

            <Dropdown menu={menuProps}>
              <Avatar
                className="w-10 h-10 cursor-pointer"
                src={preProfileLink(
                  `${profileData?.FIRST_NAME} ${profileData?.LAST_NAME}`,
                )}
              />
            </Dropdown>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto relative">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default HomeLayout;
