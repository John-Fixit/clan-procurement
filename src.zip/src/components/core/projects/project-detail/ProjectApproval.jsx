import { Select, Avatar, Tag, Space } from "antd";
import Button from "../../../shared/ui/Button";
import { IoChevronBackOutline } from "react-icons/io5";
import { useGetAllStaff } from "../../../../service/api/general";
import useCurrentUser from "../../../../hooks/useCurrentUser";
import { filePrefix } from "../../../../utils/file-prefix";
import { User } from "@heroui/react";
import { FaUser } from "react-icons/fa";

const ProjectApproval = (props) => {
  const { watch, setValue, handlePrev, handleSubmit, isSubmitting } = props;

  // Watch the approvers field from react-hook-form
  const selectedApprovers = watch("approvers") || [];
  const { userData } = useCurrentUser();

  const { data: get_staff, isPending: isLoadingStaff } = useGetAllStaff(
    userData?.data?.COMPANY_ID
  );

  const staffList = get_staff?.map((item) => {
    return {
      ...item,
      value: item?.STAFF_ID,
      // value: item?.FIRST_NAME + " " + item?.LAST_NAME,
      label: (
        <User
          avatarProps={{
            icon: <FaUser size={20} className="" />,
            radius: "full",
            src: item?.FILE_NAME ? filePrefix + item?.FILE_NAME : "",
            className:
              "w-8 h-8 my-2 object-cover rounded-full border-default-200 border",
          }}
          name={`${item?.LAST_NAME || ""} ${item?.FIRST_NAME || ""}`}
          classNames={{
            description: "w-48 truncat",
            name: "w-48 font-helvetica text-xs uppercase",
          }}
          css={{
            ".nextui-user-icon svg": {
              color: "red", // Set the color of the default icon
            },
          }}
          description={
            <div className="flex flex-co gap-y-1 justify-cente gap-x-3 m">
              {item?.DESIGNATION ? (
                <p className="font-helvetica my-auto text-black opacity-50 capitalize flex gap-x-2">
                  {item?.DESIGNATION?.toLowerCase()}
                  <span>-</span>
                </p>
              ) : null}
              <p className="font-helvetica text-black opacity-30 my-auto capitalize">
                {item?.STAFF_NUMBER}
              </p>
            </div>
          }
        />
      ),
      searchValue: `${item?.LAST_NAME || ""} ${item?.FIRST_NAME || ""} ${
        item?.STAFF_ID
      }`,
    };
  });

  return (
    <div
      style={{
        width: "100%",
        maxWidth: "800px",
        margin: "0 auto",
        padding: "24px",
      }}
    >
      <label
        style={{
          display: "block",
          fontSize: "14px",
          fontWeight: 500,
          color: "#262626",
          marginBottom: "8px",
        }}
        className="font-outfit"
      >
        Project Approvers
      </label>
      <p
        style={{
          fontSize: "14px",
          color: "#8c8c8c",
          margin: "0 0 16px 0",
        }}
        className="font-outfit"
      >
        Select team members who need to approve this project
      </p>

      <Select
        mode="multiple"
        style={{ width: "100%" }}
        placeholder="Search by name, email, or role..."
        value={selectedApprovers.map((a) => a.value)}
        onChange={(value, option) => {
          setValue("approvers", option);
        }}
        loading={isLoadingStaff}
        options={staffList}
        size="large"
        labelInValue
        maxTagCount="responsive"
        showSearch={{
          filterOption: (input, option) => {
            const approver = staffList.find((a) => a.STAFF_ID === option.value);
            if (!approver) return false;
            const searchLower = input.toLowerCase();
            return (
              `${approver?.FIRST_NAME} ${approver?.LAST_NAME}`
                .toLowerCase()
                .includes(searchLower) ||
              approver?.DESIGNATION?.toLowerCase().includes(searchLower) ||
              approver?.STAFF_NUMBER?.toLowerCase().includes(searchLower)
            );
          },
        }}
      />

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: "12px",
        }}
      >
        <span style={{ fontSize: "14px", color: "#8c8c8c" }}>
          {selectedApprovers.length} approver
          {selectedApprovers.length !== 1 ? "s" : ""} selected
        </span>
        {selectedApprovers.length > 0 && (
          <button
            type="button"
            onClick={() => setValue("approvers", [])}
            style={{
              fontSize: "14px",
              color: "#1890ff",
              background: "none",
              border: "none",
              cursor: "pointer",
              fontWeight: 500,
              padding: 0,
            }}
          >
            Clear all
          </button>
        )}
      </div>
      <div className="border-t border-gray-200 mt-10 py-6 flex justify-between">
        <Button
          radius="sm"
          color="primary"
          variant="bordered"
          onPress={handlePrev}
        >
          <IoChevronBackOutline /> Previous
        </Button>
        <Button
          radius="sm"
          color="primary"
          onPress={handleSubmit}
          isLoading={isSubmitting}
        >
          Submit
        </Button>
      </div>
    </div>
  );
};

export default ProjectApproval;
