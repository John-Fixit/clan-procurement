import useDrawerStore from "../../../hooks/useDrawerStore";
import JobOrderTemplate from "../templates/job-order/JobOrderTemplate";
import LocalPurchaseOrder from "../templates/local-purchase-order/LocalPurchaseOrder";
import CreateProject from "../projects/CreateProject";
import { Drawer } from "antd";
import AddStaff from "../role_permission/AddStaff";
import VendorDetail from "../vendor/VendorDetail";
import CreateVendor from "../vendor/create-vendor/CreateVendor";
import ProjectDetail from "../projects/project-detail/ProjectDetail";
import UpdateProcurementStatus from "../projects/project-detail/UpdateProcurementStatus";

const GeneralDrawer = () => {
  const { isOpen, closeDrawer, data } = useDrawerStore();
  const viewName = useDrawerStore((state) => state.data.viewName);

  const { title, drawerSize } = data;

  const size_1200 = ["project-detail"];
  const size_1000 = ["update-procurement-status"];

  const builtSize = size_1200.includes(viewName)
    ? 1200
    : size_1000.includes(viewName)
    ? 1000
    : null;

  return (
    <>
      <Drawer
        open={isOpen}
        onClose={closeDrawer}
        size={parseFloat(drawerSize) || builtSize || "large"}
        title={title}
      >
        {viewName === "job-order-template" && <JobOrderTemplate />}
        {viewName === "local-purchase-template" && <LocalPurchaseOrder />}
        {viewName === "create-project" && <CreateProject />}
        {viewName === "create-vendor" && <CreateVendor />}
        {viewName === "add-staff-role-permission" && <AddStaff />}
        {viewName === "vendor-detail" && <VendorDetail />}
        {viewName === "project-detail" && <ProjectDetail />}
        {viewName === "update-procurement-status" && (
          <UpdateProcurementStatus />
        )}
      </Drawer>
    </>
  );
};

export default GeneralDrawer;
